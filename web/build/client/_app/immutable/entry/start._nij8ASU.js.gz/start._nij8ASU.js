import{l as o,a as r}from"../chunks/B4mQZ9mf.js";export{o as load_css,r as start};
