import{l as o,a as r}from"../chunks/BeYj1-5O.js";export{o as load_css,r as start};
